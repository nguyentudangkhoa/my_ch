<?php $__env->startSection('content'); ?>
    <style>
        .loginWrapper {
            float: unset;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        #loginForm {
            float: unset;
        }
    </style>
    <div class="loginWrapper">
        <div id="loginForm">
            <div class="title-nb">
                Đăng nhập vào Admin
            </div>
            <form action="<?php echo e(route('admin.auth.login')); ?>" class="form" method="POST">
                <?php echo csrf_field(); ?>
                <fieldset>
                    <div class="formRow">
                        <div class="loginInput"><input type="text" name="user_name" placeholder="Tên người dùng" class="validate[required]" id="username"></div>
                        <div class="clear"></div>

                        <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="formRow">
                        <div class="loginInput"><input type="password" name="password" placeholder="Mật khẩu" class="validate[required]" id="pass"></div>
                        <div class="clear"></div>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="q-mk"><a href=""></a><a href="../../quen-mat-khau-shop.html">Quên mật khẩu ?</a></div>
                    <div class="loginControl">
                        <input type="submit" value="Đăng nhập" class="dredB logMeIn">
                        <div class="clear"></div>
                    </div>
                    <div class="ajaxloader"><img src="images/loader.gif" alt="loader"></div>
                    <div id="loginError">
                    </div>
                </fieldset>
            </form>
        </div>
        <div class="clear"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.login_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_ch\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>