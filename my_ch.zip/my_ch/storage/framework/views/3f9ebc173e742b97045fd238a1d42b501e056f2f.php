<?php $__env->startSection('content'); ?>
    <div class="count-product">
        <a class="c-pro-all">Shop tạm nghỉ / đóng</a>
    </div>
    <?php echo $__env->make('admin.product.partials.search-box', ['action' => route('admin.product.all_product'), 'categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="widget">
        <div class="responsive-table">
            <table cellpadding="0" cellspacing="0" width="100%" class="table-order-title sTable withCheck mTable" id="checkAll">
                <thead>
                <tr style="background-color: #e5e5e5">
                    <th style="text-align: center;"><input type="checkbox" name="" id="allProduct"></th>
                    <th style="text-align: inherit;">Sản Phẩm</th>
                    <th style="text-align: inherit;">Shop</th>
                    <th style="text-align: inherit;">Ngày đăng / sửa</th>
                    <th style="text-align: center;">GG Shopping</th>
                </tr>
                </thead>
                <tbody style="background-color: #fff">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center;"><input type="checkbox" name="" id="product<?php echo e($product->id); ?>" value="<?php echo e($product->id); ?>"></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->shop->shop_title); ?></td>
                        <td><?php echo e($product->updated_at); ?></td>
                        <td style="text-align: center;">
                            <label class="toggle-table">
                                <input type="checkbox" <?php if($product->ggsp != 0): ?> checked <?php endif; ?>>
                                <span class="slider"></span>
                            </label>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vnsmychad/domains/admin.mych.vn/public_html/resources/views/admin/product/all_product.blade.php ENDPATH**/ ?>