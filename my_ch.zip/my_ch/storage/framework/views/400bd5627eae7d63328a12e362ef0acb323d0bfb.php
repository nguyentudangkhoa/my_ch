<div class="widget">
    <div class="titlee">
        <div class="timkiem">
            <form name="search" action="<?php echo e($action); ?>" method="GET" class="form giohang_ser">
                <input class="form_or" name="keyword" placeholder="Nhập từ khóa.." value="<?php echo e(request()->query('keyword') ?: ''); ?>" type="text">
                <input type="submit" class="blueB" value="Tìm kiếm" style="width:100px;">
                <div class="clear"></div>
            </form>
        </div><!--end tim kiem-->
    </div>
</div>
<?php /**PATH /Users/nguyentudangkhoa/Downloads/mych_laravel/resources/views/admin/shop/partials/search-box.blade.php ENDPATH**/ ?>