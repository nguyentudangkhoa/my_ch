<?php $__env->startSection('content'); ?>
    <div class="control_frm">
        <div class="bc">
            <ul id="breadcrumbs" class="breadcrumbs">
                <li><a href="<?php echo e(route('admin.shop.new_shop')); ?>"><span>Quản lý Shop</span></a></li>
                <li class="current"><a href="<?php echo e(route('admin.shop.new_shop')); ?>"><span>Shop mới tạo</span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
    </div>
    <?php echo $__env->make('admin.shop.partials.search-box', ['action' => route('admin.shop.new_shop')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="widget">
        <div class="count-product">
            <a class="c-pro-all">Shop mới tạo</a>
            <a class="c-link" href="index.php?com=product&amp;act=add&amp;type=product">+ Thêm 1 shop mới</a>
        </div>
        <div class="responsive-table">
            <table cellpadding="0" cellspacing="0" width="100%" class="table-order-title sTable withCheck mTable" id="checkAll">
                <thead>
                <tr style="background-color: #fff">
                    <th class="sortCol">Tên shop</th>
                    <th class="sortCol-sl">Email</th>
                    <th style="text-align: center;">Địa chỉ</th>
                    <th style="text-align: center;">Điện Thoại</th>
                </tr>
                </thead>
                <tbody style="background-color: #fff">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($shop->shop_title); ?></td>
                        <td><?php echo e($shop->email); ?></td>
                        <td><?php echo e($shop->address); ?></td>
                        <td><?php echo e($shop->phone_number); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
    <?php echo e($shops->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vnsmychad/domains/admin.mych.vn/public_html/resources/views/admin/shop/index.blade.php ENDPATH**/ ?>