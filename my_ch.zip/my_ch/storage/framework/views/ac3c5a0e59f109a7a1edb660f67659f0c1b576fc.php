<?php $__env->startSection('content'); ?>
    <div class="count-product">
        <a class="c-pro-all">Tổng doanh thu trong nước</a>
    </div>
    <div class="responsive-table">
        <table cellpadding="0" cellspacing="0" width="100%" class="table-order-title sTable withCheck mTable" id="checkAll">
            <thead>
            <tr style="background-color: #e5e5e5">
                <th >Doanh thu năm</th>
                <th >Doanh thu tháng</th>
                <th >Doanh thu tuần</th>
                <th >Phí vận chuyển</th>
                <th >Phí giao dịch</th>
            </tr>
            </thead>
            <tbody style="background-color: #fff">
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td >0
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="widget">
        <div class="responsive-table">
            <table cellpadding="0" cellspacing="0" width="100%" class="table-order-title sTable withCheck mTable" id="checkAll">
                <thead>
                <tr style="background-color: #e5e5e5">
                    <th >Shop</th>
                    <th >Doanh thu năm</th>
                    <th >Doanh thu tháng</th>
                    <th >Phí vận chuyển</th>
                    <th >Phí giao dịch</th>
                </tr>
                </thead>
                <tbody style="background-color: #fff">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($shop->shop_title); ?></td>
                        <td><?php echo e($shop->orders->sum('total_price')); ?></td>
                        <td><?php echo e($shop->orders->sum('payment_price')); ?></td>
                        <td><?php echo e($shop->orders->sum('payment_price')); ?></td>
                        <td >0
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo e($shops->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nguyentudangkhoa/Downloads/mych_laravel/resources/views/admin/finance/index.blade.php ENDPATH**/ ?>