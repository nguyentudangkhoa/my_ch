<div id="leftSide">
    <div class="sidebarSep mt0"></div>
    <ul id="menu" class="nav">
        <li class="dash" id="menu1"><a class=" active" title="" href="<?php echo e(route('admin.auth.login')); ?>"><span>Trang chủ</span></a></li>
        <li class="categories_li " id="menu2"><a href="" title="" class="exp inactive"><span>Quản lý tài chính</span></a>
            <ul class="sub" style="display: none;">
                <li><a href="<?php echo e(route('admin.shop.internal_shop')); ?>" title="">Shop trong nước</a></li>
                <li><a href="<?php echo e(route('admin.shop.overseas_shop')); ?>" title="">Shop ngoài nước</a></li>
                <li class="last"><a href="" title="">Rút tiền</a></li>
            </ul>
        </li>
        <li class="categories_li " id="menu3"><a href="" title="" class="exp inactive"><span>Quản lý shop</span></a>
            <ul class="sub" style="display: none;">
                <li><a href="<?php echo e(route('admin.shop.new_shop')); ?>" title="">Shop mới tạo</a></li>
                <li><a href="<?php echo e(route('admin.shop.pause_shop')); ?>" title="">Shop tạm nghỉ / đóng</a></li>
                <li class="last"><a href="" title="">Rút tiền</a></li>
            </ul>
        </li>
        <li class="categories_li " id="menu4"><a href="" title="" class="exp inactive"><span>Quản lý sản phẩm</span></a>
            <ul class="sub" style="display: none;">
                <li><a href="<?php echo e(route('admin.product.index')); ?>" title="">Sản phẩm mới</a></li>
                <li><a href="<?php echo e(route('admin.product.all_product')); ?>" title="">Tất cả sản phẩm</a></li>
            </ul>
        </li>
    </ul>
</div>
<?php /**PATH /home/vnsmychad/domains/admin.mych.vn/public_html/resources/views/admin/app/partials/menu.blade.php ENDPATH**/ ?>