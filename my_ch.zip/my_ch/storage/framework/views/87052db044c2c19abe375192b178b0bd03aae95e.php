<?php $__env->startSection('content'); ?>
    <style>
        .table-order-title tr th {
            padding: 10px 0px;
        }

        .sTable tbody th {
            /* border-left: 1px solid #f1f1f1!important; */
            padding: 6px;
            vertical-align: middle;
            font-size: 12px;
        }

        .withCheck thead tr th:first-child, .withCheck thead tr th:first-child {
            padding: 11px 10px;
        }

        .responsive-table {
            overflow-y: scroll;
        }
    </style>

    <div class="widget">
        <div class="titlee">
            <div class="timkiem">
                <form name="search" action="index.php" method="GET" class="form giohang_ser">
                    <input class="form_or" name="keyword" placeholder="Nhập từ khóa.." value="" type="text">
                    <input type="submit" class="blueB" value="Tìm kiếm" style="width:100px;">
                    <div class="clear"></div>
                </form>
            </div><!--end tim kiem-->
        </div>
    </div>
    <div class="widget responsive-table">
        <table cellpadding="0" cellspacing="0" width="100%" class="table-order-title sTable withCheck mTable" id="checkAll">
            <thead>
                <tr style="background-color: #fff">
                    <th class="sortCol">Tên shop</th>
                    <th class="sortCol-sl">Email</th>
                    <th style="text-align: center;">Địa chỉ</th>
                    <th style="text-align: center;">Điện Thoại</th>
                </tr>
            </thead>
            <tbody style="background-color: #fff">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($shop->shop_title); ?></td>
                        <td><?php echo e($shop->email); ?></td>
                        <td><?php echo e($shop->address); ?></td>
                        <td><?php echo e($shop->phone_number); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($shops->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vnsmychad/domains/admin.mych.vn/public_html/resources/views/admin/home/index.blade.php ENDPATH**/ ?>