<div class="widget">
    <div class="titlee">
        <div class="timkiem">
            <form name="search" action="<?php echo e($action); ?>" method="GET" class="form giohang_ser">
                <div class="search">
                    <select id="category" name="category_id" class="main_select">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input class="form_or" name="keyword" placeholder="Nhập tên hoặc mã sản phẩm" value="<?php echo e(request()->query('keyword') ?: ''); ?>" type="text">
                <input type="submit" class="blueB" value="Tìm kiếm" style="width:100px;">
                <div class="clear"></div>
            </form>
        </div><!--end tim kiem-->
    </div>
</div>
<?php /**PATH /home/vnsmychad/domains/admin.mych.vn/public_html/resources/views/admin/product/partials/search-box.blade.php ENDPATH**/ ?>