<div id="leftSide">
    <div class="sidebarSep mt0"></div>
    <ul id="menu" class="nav">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="categories_li <?php echo e($menu['icon']); ?> <?php if($menu['is_active']): ?> active <?php endif; ?>"><a href="<?php echo e($menu['url']); ?>" title=""
                    class="exp"><span><?php echo e($menu['name']); ?></span>
                    <?php if(isset($menu['children']) && count($menu['children']) > 0): ?>
                        <span class="arrow-up"></span>
                    <?php endif; ?>
                </a>
                <?php if(isset($menu['children']) && count($menu['children']) > 0): ?>
                    <ul class="sub" style="display: none;">
                        <?php $__currentLoopData = $menu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($child['url']); ?>"  <?php if($child['is_active']): ?> class="active" <?php endif; ?> title=""><?php echo e($child['name']); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\my_ch\resources\views/admin/app/partials/menu.blade.php ENDPATH**/ ?>