<?php

use App\Http\Controllers\Admin\ProductController;
use Illuminate\Support\Facades\Route;

Route::middleware('is_login')->prefix('product')->name('product.')->group(function () {
    Route::get('', [ProductController::class, 'index'])->name('index');
    Route::get('/all-product', [ProductController::class, 'getProduct'])->name('all_product');
});
