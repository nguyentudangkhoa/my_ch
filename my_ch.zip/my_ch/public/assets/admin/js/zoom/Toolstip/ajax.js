/* Simple AJAX Code-Kit (SACK) */
/* ©2005 Gregory Wild-Smith */
/* www.twilightuniverse.com */
/* Software licenced under a modified X11 licence, see documentation or authors website for more details */

function sack(file)
{
	this.AjaxFailedAlert = "Trình duyệt của bạn không hỗ trợ Load Ajax. Bạn nên chọn một trình duyệt khác để sử dụng được tất cả chức năng của hệ thống.\n";
	this.requestFile = file;
	this.method = "POST";
	this.URLString = "";
	this.encodeURIString = true;
	this.execute = false;

	this.onLoading = function() { };
	this.onLoaded = function() { };
	this.onInteractive = function() { };
	this.onCompletion = function() { };

	this.createAJAX = function() 
	{
		try 
		{
			this.xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		} 
		catch (e) 
		{
			try 
			{
				this.xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} 
			catch (err) 
			{
				this.xmlhttp = null;
			}
		}
		
		if(!this.xmlhttp && typeof XMLHttpRequest != "undefined")
			this.xmlhttp = new XMLHttpRequest();
			
		if (!this.xmlhttp)
		{
			this.failed = true; 
		}
	};
	
	this.setVar = function(name, value)
	{
		if (this.URLString.length < 3){
			this.URLString = name + "=" + value;
		} else {
			this.URLString += "&" + name + "=" + value;
		}
	}
	
	this.encVar = function(name, value)
	{
		var varString = encodeURIComponent(name) + "=" + encodeURIComponent(value);
		return varString;
	}
	
	this.encodeURLString = function(string)
	{
		varArray = string.split('&');
		for (i = 0; i < varArray.length; i++)
		{
			urlVars = varArray[i].split('=');
			
			if (urlVars[0].indexOf('amp;') != -1)
			{
				urlVars[0] = urlVars[0].substring(4);
			}
			
			varArray[i] = this.encVar(urlVars[0],urlVars[1]);
		}
		return varArray.join('&');
	}
	
	this.runResponse = function()
	{
		eval(this.response);
	}
	
	this.runAJAX = function(urlstring)
	{
		this.responseStatus = new Array(2);
		
		if(this.failed && this.AjaxFailedAlert)
		{ 
			alert(this.AjaxFailedAlert); 
		} 
		else 
		{
			if (urlstring)
			{ 
				if (this.URLString.length)
				{
					this.URLString = this.URLString + "&" + urlstring; 
				} 
				else 
				{
					this.URLString = urlstring; 
				}
			}
			
			if (this.encodeURIString)
			{
				var timeval = new Date().getTime(); 
				this.URLString = this.encodeURLString(this.URLString);
				this.setVar("rndval", timeval);
			}
			
			if (this.element) 
			{ 
				this.elementObj = document.getElementById(this.element); 
			}
			
			if (this.xmlhttp)
			{
				var self = this;
				if (this.method == "GET") 
				{
					var totalurlstring = this.requestFile + "?" + this.URLString;
					this.xmlhttp.open(this.method, totalurlstring, true);
				} 
				else 
				{
					this.xmlhttp.open(this.method, this.requestFile, true);
				}
				
				if (this.method == "POST")
				{
  					try 
  					{
						this.xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded')  
					} 
					catch (e) {}
				}

				this.xmlhttp.send(this.URLString);
				
				this.xmlhttp.onreadystatechange = function() 
				{
					switch (self.xmlhttp.readyState)
					{
						case 1:
							self.onLoading();
							break;
							
						case 2:
							self.onLoaded();
							break;
							
						case 3:
							self.onInteractive();
							break;
							
						case 4:
							self.response = self.xmlhttp.responseText;
							self.responseXML = self.xmlhttp.responseXML;
							self.responseStatus[0] = self.xmlhttp.status;
							self.responseStatus[1] = self.xmlhttp.statusText;
							self.onCompletion();
							
							if(self.execute)
							{ 
								self.runResponse(); 
							}
							
							if (self.elementObj) 
							{
								var elemNodeName = self.elementObj.nodeName;
								elemNodeName.toLowerCase();
								
								if (elemNodeName == "input" || elemNodeName == "select" || elemNodeName == "option" || elemNodeName == "textarea")
								{
									self.elementObj.value = self.response;
								} 
								else 
								{
									self.elementObj.innerHTML = self.response;
								}
							}
							
							self.URLString = "";
							break;
						}
				};
			}
		}
	};
	
	this.createAJAX();
}