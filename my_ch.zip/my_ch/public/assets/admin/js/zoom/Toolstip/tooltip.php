﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head><title>
	Popup
</title></head>
<body>
    
<div>

</div>

      
<div id="AjaxPopup">
<div id="AjaxPopupText">

<span id="AjaxPopup1_lblHeader" class="sumctsHeadline">Cổ tích cho những hy vọng không thành...</span><br />
<span id="AjaxPopup1_lblTime" class="sumctsDateTime">2010-12-31 00:00:00 </span>
<br />
<img id="AjaxPopup1_img" src="1.jpg" style="border-width:1px;border-style:solid;" width="90" />
<span id="AjaxPopup1_lblSummary" class="sumctsSummary">Nếu chỉ nhìn mọi việc dưới con mắt của mình, thì mọi thứ chẳng có gì là hoàn hảo, trọn vẹn cả. Không thể đánh giá Trái Đất chỉ bằng con mắt của Mặt Trời hoặc Mặt trăng được. Cũng vậy khi đánh giá một con người, một sự việc nào đó, không thể nhìn từ một phía được... <BR></span>
</div>
</div>
    </form>
</body>
</html>

